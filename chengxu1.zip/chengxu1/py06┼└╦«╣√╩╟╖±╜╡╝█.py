from bs4 import BeautifulSoup
import requests, sys
import io

# target = 'http://www.flstudiochina.com/newbuy.html?onlineid=1850'
# req = requests.get(url=target)
# print(req.text)
# <div class="mt25 dib"> 

from bs4 import BeautifulSoup
import requests
if __name__ == "__main__":
     target = 'http://www.flstudiochina.com/newbuy.html?onlineid=1850'
     req = requests.get(url = target)
     html = req.text
     bf = BeautifulSoup(html)
     texts = bf.find_all('b', class_ = "fs15 online_price")
     print(texts)
     print (type(texts))
     # for text in texts():
     # 	print  text   # print texts.text
     # aas=texts
